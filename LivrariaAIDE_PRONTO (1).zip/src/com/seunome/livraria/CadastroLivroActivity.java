package com.seunome.livraria;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class CadastroLivroActivity extends Activity {

    EditText titulo,autor,preco,estoque;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_cadastro_livro);

        titulo = findViewById(R.id.edtTitulo);
        autor = findViewById(R.id.edtAutor);
        preco = findViewById(R.id.edtPreco);
        estoque = findViewById(R.id.edtEstoque);
        db = new DatabaseHelper(this);

        findViewById(R.id.btnSalvar).setOnClickListener(v -> salvar());
    }

    private void salvar(){
        SQLiteDatabase banco = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("titulo", titulo.getText().toString());
        cv.put("autor", autor.getText().toString());
        cv.put("preco", Double.parseDouble(preco.getText().toString()));
        cv.put("estoque", Integer.parseInt(estoque.getText().toString()));

        banco.insert("livros",null,cv);
        finish();
    }
}
