package com.seunome.livraria;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "livraria.db";

    public DatabaseHelper(Context c){
        super(c, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE usuarios(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, email TEXT, senha TEXT, tipo TEXT)");
        db.execSQL("CREATE TABLE livros(id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT, autor TEXT, preco REAL, estoque INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int v1,int v2){}
}
