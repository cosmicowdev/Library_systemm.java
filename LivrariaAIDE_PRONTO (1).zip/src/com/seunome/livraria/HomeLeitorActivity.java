package com.seunome.livraria;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.text.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;

public class HomeLeitorActivity extends Activity {

    ListView lista;
    EditText pesquisa;
    DatabaseHelper db;
    ArrayList<Livro> livros = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_home_leitor);

        lista = findViewById(R.id.listaLivros);
        pesquisa = findViewById(R.id.edtPesquisa);
        db = new DatabaseHelper(this);

        carregar("");

        pesquisa.addTextChangedListener(new TextWatcher(){
            public void onTextChanged(CharSequence s,int a,int b,int c){
                carregar(s.toString());
            }
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void afterTextChanged(Editable e){}
        });
    }

    private void carregar(String filtro){
        livros.clear();
        SQLiteDatabase banco = db.getReadableDatabase();

        Cursor c = banco.rawQuery(
          "SELECT * FROM livros WHERE titulo LIKE ?",
          new String[]{"%"+filtro+"%"}
        );

        while(c.moveToNext()){
            Livro l = new Livro();
            l.titulo = c.getString(1);
            l.autor = c.getString(2);
            l.preco = c.getDouble(3);
            l.estoque = c.getInt(4);
            livros.add(l);
        }

        lista.setAdapter(new LivroAdapter(this, livros));
    }
}
