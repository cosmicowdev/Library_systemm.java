package com.seunome.livraria;

public class Livro {
    public int id;
    public String titulo;
    public String autor;
    public double preco;
    public int estoque;
}
