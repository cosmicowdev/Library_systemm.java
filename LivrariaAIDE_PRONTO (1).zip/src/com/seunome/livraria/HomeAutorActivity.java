package com.seunome.livraria;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;

public class HomeAutorActivity extends Activity {

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_home_autor);

        findViewById(R.id.btnNovoLivro).setOnClickListener(v ->
            startActivity(new Intent(this, CadastroLivroActivity.class))
        );
    }
}
