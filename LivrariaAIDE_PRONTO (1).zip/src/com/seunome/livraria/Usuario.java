package com.seunome.livraria;

public class Usuario {
    public int id;
    public String nome;
    public String email;
    public String senha;
    public String tipo;
}
