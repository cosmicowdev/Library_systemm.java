package com.seunome.livraria;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class CadastroActivity extends Activity {

    EditText nome,email,senha;
    Spinner tipo;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_cadastro);

        nome = findViewById(R.id.edtNome);
        email = findViewById(R.id.edtEmail);
        senha = findViewById(R.id.edtSenha);
        tipo = findViewById(R.id.spTipo);

        db = new DatabaseHelper(this);

        findViewById(R.id.btnCadastrar).setOnClickListener(v -> cadastrar());
    }

    private void cadastrar(){
        SQLiteDatabase banco = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome.getText().toString());
        cv.put("email", email.getText().toString());
        cv.put("senha", senha.getText().toString());
        cv.put("tipo", tipo.getSelectedItem().toString());

        banco.insert("usuarios",null,cv);
        finish();
    }
}
