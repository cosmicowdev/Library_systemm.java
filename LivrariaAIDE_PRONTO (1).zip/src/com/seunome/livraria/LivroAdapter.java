package com.seunome.livraria;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class LivroAdapter extends BaseAdapter {

    Context c;
    ArrayList<Livro> livros;

    public LivroAdapter(Context c, ArrayList<Livro> livros){
        this.c = c;
        this.livros = livros;
    }

    public int getCount(){ return livros.size(); }
    public Object getItem(int i){ return livros.get(i); }
    public long getItemId(int i){ return i; }

    public View getView(int i, View v, ViewGroup g){
        if(v == null)
            v = LayoutInflater.from(c).inflate(R.layout.item_livro,g,false);

        TextView t = v.findViewById(R.id.txtTitulo);
        TextView a = v.findViewById(R.id.txtAutor);
        TextView p = v.findViewById(R.id.txtPreco);
        TextView e = v.findViewById(R.id.txtEstoque);

        Livro l = livros.get(i);

        t.setText(l.titulo);
        a.setText("Autor: "+l.autor);
        p.setText("R$ "+l.preco);
        e.setText("Estoque: "+l.estoque);

        return v;
    }
}
