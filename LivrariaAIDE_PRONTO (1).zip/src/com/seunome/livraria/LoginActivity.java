package com.seunome.livraria;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class LoginActivity extends Activity {

    EditText email, senha;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.edtEmail);
        senha = findViewById(R.id.edtSenha);
        db = new DatabaseHelper(this);

        findViewById(R.id.btnLogin).setOnClickListener(v -> login());
        findViewById(R.id.btnCadastro).setOnClickListener(v ->
            startActivity(new Intent(this, CadastroActivity.class))
        );
    }

    private void login(){
        SQLiteDatabase banco = db.getReadableDatabase();
        Cursor c = banco.rawQuery(
          "SELECT tipo FROM usuarios WHERE email=? AND senha=?",
          new String[]{ email.getText().toString(), senha.getText().toString()}
        );

        if(c.moveToFirst()){
            String tipo = c.getString(0);
            if(tipo.equals("autor"))
                startActivity(new Intent(this, HomeAutorActivity.class));
            else
                startActivity(new Intent(this, HomeLeitorActivity.class));
        } else {
            Toast.makeText(this,"Login inválido",Toast.LENGTH_SHORT).show();
        }
    }
}
